import axios from "axios";
async function GetCourseDetails(id) {

    try {
        const respons = await axios.post(
            "https://test.plan-b-eg.com/api/Account/authenticate",
            JSON.stringify( "basem.ashraf@smartapp-eg.com", "123@@@" ),
            {
              headers: { "Content-Type": "application/json" },
              withCredentials: true,
            }
          );
          const accessToken = respons?.data?.accessToken;
    
      const response = await axios.get('https://test.plan-b-eg.com/api/Courses/GetCourseDetails?courseId='+id+'&lang=en',
      {
        headers : {
            'Content-Type' : 'application/json',
            'Accept' : 'application/json',
            'Authorization' : 'Bearer <token_here>'
          }
      }
      );
      console.log(response);
    } catch (error) {
      console.error(error);
    }
  }
  export default GetCourseDetails;